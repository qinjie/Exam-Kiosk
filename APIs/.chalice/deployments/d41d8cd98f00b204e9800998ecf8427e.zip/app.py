import json
import datetime
import pymysql
from chalice import Chalice

db_host = "ec2-13-228-113-29.ap-southeast-1.compute.amazonaws.com"
db_name = "exam_kiosk"
db_username = "ecer"
db_password = "Soe7014Ece"


app = Chalice(app_name="exam_kiosk")


@app.route("seat/{rfid}")
def index(rfid):
    result = []
    conn = connect_database()
    with conn.cursor() as cur:
        cur.execute("SELECT `card`, `name`, `module`, `exam_date`, `exam_venue`, `start_time`, `end_time`, `seat_number` FROM `exam_seating` WHERE `card` = (select card from user where `rfid` = '{}')"
                                    .format(rfid))
    for row in cur:
        result.append({'card':str(row[0]),'name':str(row[1]),'module':str(row[2]),'date':str(row[3]),'venue':str(row[4]),'start_time':str(row[5]),'end_time':str(row[6]),'seat':str(row[7])})
    return json.dumps(result)

@app.route('/toilet/student/{student_rfid}/staff/{staff_rfid}')
def toilet(student_rfid, staff_rfid):
    conn = connect_database()
    student_card = ''
    student_name = ''
    module = ''
    exam_venue = ''
    staff_card = ''
    with conn.cursor() as cur:
        cur.execute("SELECT `card`, `name`, `module`, `exam_venue` FROM `exam_seating` WHERE `card` = (select card from user where `rfid` = '{}')"
                                    .format(student_rfid))
    for row in cur:
        student_card = str(row[0])
        student_name = str(row[1])
        module = str(row[2])
        exam_venue = str(row[3])
        break

    with conn.cursor() as cur:
        cur.execute("select `card` from user where `rfid` = '{}'".format(staff_rfid))
    for row in cur:
        staff_card = str(row[0])
        break

    with conn.cursor() as cur:
        response = cur.execute("INSERT INTO `toilet_trip`(`card`, `name`, `module`, `exam_venue`, `staff_card`) VALUES (%s,%s,%s,%s,%s)",(student_card, student_name, module, exam_venue, staff_card))
        conn.commit()

    if response > 0:
        return 'Toilet success'
    else:
        return 'Toilet fail'

def connect_database():
    try:
        conn = pymysql.connect(db_host, user=db_username, passwd=db_password, db=db_name, connect_timeout=5)
    except Exception as e:
        conn = pymysql.connect()
        print (e)
    print("SUCCESS: Connection to RDS mysql instance succeeded")
    return conn